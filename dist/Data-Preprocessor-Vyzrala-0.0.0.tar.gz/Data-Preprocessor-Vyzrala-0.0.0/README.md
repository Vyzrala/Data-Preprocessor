# Data-Preprocessor

Python pakage for data normalization using numpy.
> Transforming and inverse transforming data.

*Pakage available in 'sdist' directory*
