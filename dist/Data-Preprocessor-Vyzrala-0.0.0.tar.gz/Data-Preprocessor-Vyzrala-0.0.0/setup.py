import setuptools

setuptools.setup(
    name="Data-Preprocessor-Vyzrala",
    varsion="0.0.2",
    author="Marcin Hebdzyński",
    author_email="hebdzynski.m@gmail.com",
    url="https://github.com/Vyzrala/Data-Preprocessor",
    packages=setuptools.find_packages(),
    python_requires=">=3.6",
)